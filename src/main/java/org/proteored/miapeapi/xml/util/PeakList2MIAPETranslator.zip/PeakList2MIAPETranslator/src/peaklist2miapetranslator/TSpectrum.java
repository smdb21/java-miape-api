/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package peaklist2miapetranslator;

import java.util.Vector;

/**
 *
 * @author Alberto
  */


//Para la lectura de picos. Más que espectrum, debería de decir conjunto, pero bueno

public class TSpectrum {

    
    public TSpectrum(String _spot_id, String _job_item_id, String _peak_list_id, 
                              double _mz)
    {
        PeptideMz = _mz;
        SetPeptideCharge(-1);
        Spot_id = _spot_id;
        job_item_id = _job_item_id;
        peak_list_id = _peak_list_id;

        try
        {
            MyPeakList = new TBase64PeakList();
        }
        catch(Exception ex1) {
            ex1.printStackTrace();
        }
    }

    TSpectrum() {
        throw new UnsupportedOperationException("Not yet implemented");
    }
    
    public void FillMassValues(Vector _mass, Vector _intensities)
    {
        this.GetPeakList().InicializeSpectrum(_mass.size(),INTENSITY);
        this.FillMassValues(_mass, MZ);
        this.FillMassValues(_intensities,INTENSITY);
    }
    
    public void FillMassValues (Vector _values, int _mode)
    {
        int i;
        double _aux_value;
        for (i=0;i<_values.size();i++)
        {
            _aux_value = Double.parseDouble((String) _values.elementAt(i));
            if (_mode==MZ)
                this.MyPeakList.AddMzElement(i, _aux_value);
            else
                this.MyPeakList.AddIntensityElement(i, _aux_value);
        }
    }
    
    public String GetSpot_id()
    {
        return (Spot_id);
    }
    public String GetJob_item_id()
    {
        return (job_item_id);
    }
    public String GetPeak_list_id()
    {
        return (peak_list_id);
    }
    public double GetPeptideMz()
    {
        return (PeptideMz);
    }
    public double GetPeptideMass()
    {
        return (PeptideMass);
    }
    public double GetPeptideMoverZ()
    {
        return (PeptideMz);
    }
    public int GetPeptideCharge()
    {
        return (PeptideCharge);
    }
    //nuevo
    public void SetPeptideCharge(int _value)
    {
        if (_value > 0)
        {
            PeptideCharge = _value;
            //calculamos la masa monoparental
            SetPeptideMass((GetPeptideMz() - 1) * PeptideCharge);
        }
    }
    private void SetPeptideMass (double _value)
    {
        PeptideMass = _value;
    }
    private void SetMoverZ (double _value)
    {
       PeptideMz = _value;
    }
    public TBase64PeakList GetPeakList()
    {
        return (MyPeakList);
    }
    private TBase64PeakList MyPeakList;
    public static final int MZ = 1;
    public static final int INTENSITY = 2;
    private double PeptideMass;
    private double PeptideMz;
    //Nueva variable.
    //Tabla hash para la informaci�n adicional
    //novedad para la carga
    private int PeptideCharge;
    //modos para la lectura
    private String Spot_id;
    private String job_item_id;
    private String peak_list_id;
    
    
}

