// Decompiled by DJ v3.7.7.81 Copyright 2004 Atanas Neshkov  Date: 12/14/2007 12:59:38 PM
// Home Page : http://members.fortunecity.com/neshkov/dj.html  - Check often for new version!
// Decompiler options: packimports(3)
// Source File Name:   TPeptideInformation.java
//NOTAS:
//FIRMADO EL APPLET EN PORTATIL


package peaklist2miapetranslator;


public class TPeptideInformation
{

    public TPeptideInformation()
    {
        PeptideSequence = "NA";
        PeptideMass = 0.0D;
        Spot_id = "";
        job_item_id = "";
        peak_list_id = "";
        try
        {
            MyPeakList = new TBase64PeakList();
        }
        catch(Exception ex) { }
    }


    public String GetPeptideSequence()
    {
        return PeptideSequence;
    }

    public double GetPeptideMass()
    {
        return PeptideMass;
    }

    public int GetPeptideCharge()
    {
        return PeptideCharge;
    }


    public TBase64PeakList GetPeakList()
    {
      return (MyPeakList);
    }

    public String GetSpectrumReference()
    {
        return GetPeakList().GetSpectrumReference();
    }

    public int GetMzArrayCount()
    {
        return GetPeakList().GetMzArrayCount();
    }

    public double[] GetMzArray()
    {
        return GetPeakList().GetMzArray();
    }

    public double[] GetIntensityArray()
    {
        return GetPeakList().GetIntensityArray();
    }

    public double GetMzElement(int _pos)
    {
        double _ret = -1D;
        if(_pos < GetMzArrayCount())
            _ret = GetMzArray()[_pos];
        return _ret;
    }

    public double GetIntensityElement(int _pos)
    {
        double _ret = -1D;
        if(_pos < GetMzArrayCount())
            _ret = GetIntensityArray()[_pos];
        return _ret;
    }

    public double GetRelativeIntensityElement(int _pos)
    {
        double _ret = GetIntensityElement(_pos);
        if(_ret > (double)0)
            _ret /= GetMaxIntensity();
        return _ret;
    }

    public double GetMinMass()
    {
        return GetPeakList().GetMinMass();
    }

    public double GetMaxMass()
    {
        return GetPeakList().GetMaxMass();
    }

    public double GetMinIntensity()
    {
        return GetPeakList().GetMinIntensity();
    }

    public double GetMaxIntensity()
    {
        return GetPeakList().GetMaxIntensity();
    }



    //Set methods

    public void SetPeptideMass(double _arg)
    {
        PeptideMass = _arg;
    }

    public void SetPeptideCharge(int _arg)
    {
        PeptideCharge = _arg;
    }


    //M�todo nuevo para insertar el peaklist
    //La instancia est� creada, pero ahora le enviamos todos los
    //datos desde la lectura externa.



    public void SetSpectrumReference(String _reference)
    {
        GetPeakList().SetSpectrumReference(_reference);
    }

    public void SetMzArrayCount(int _count)
    {
        GetPeakList().SetMzArrayCount(_count);
    }
    public void SetMinMass(double _arg)
    {
        GetPeakList().SetMinMass(_arg);
    }

    public void SetMaxMass(double _arg)
    {
        GetPeakList().SetMaxMass(_arg);
    }

    public void SetMinIntensity(double _arg)
    {
        GetPeakList().SetMinIntensity(_arg);
    }

    public void SetMaxIntensity(double _arg)
    {
        GetPeakList().SetMaxIntensity(_arg);
    }
    public void CreatePeakList (String _mzdatabinary, String _intensitydatabinary,
                                int _mzdatacount, String _mzdataprecision, String _mzdatacodification)
    {
      //Pasamos los valores a la clase y que empiece  funcionar;
      GetPeakList().SetBinaryMzArray(_mzdatabinary);
      GetPeakList().SetBinaryIntensityArray(_intensitydatabinary);
      GetPeakList().SetMzArrayCount(_mzdatacount);
      GetPeakList().SetMzDataPrecision(_mzdataprecision);
      GetPeakList().SetMzDataCode(_mzdatacodification);
      GetPeakList().MzDatatoBinary();
    }
    //Nueva clase
    private TBase64PeakList MyPeakList;
    //Lo que si los datos de la base de datos
    private String Spot_id;
    private String job_item_id;
    private String peak_list_id;
    
    public static final int MZ = 1;
    public static final int INTENSITY = 2;
    private String PeptideSequence;
    private double PeptideMass;
    private int PeptideCharge;    
    //modos para la lectura
}